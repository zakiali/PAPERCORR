#ifndef RX_MODULE_H
#define RX_MODULE_H

#include <Python.h>
#include "structmember.h"
#include "numpy/arrayobject.h"
#include "corrpacket_obj.h"
#include "buffersocket_obj.h"
#include "collatebuffer_obj.h"

#endif
